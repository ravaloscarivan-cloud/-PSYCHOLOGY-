<?php
require "config.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($email === "" || $pass === "") {
        $mensaje = "❌ Todos los campos son obligatorios";
    } else {

        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($pass, $user['password'])) {
                $mensaje = "✅ Inicio de sesión correcto";
                // header("Location: dashboard.php");
                // exit;
            } else {
                $mensaje = "❌ Contraseña incorrecta";
            }
        } else {
            $mensaje = "❌ El usuario no existe";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar sesión</title>
    <link rel="stylesheet" href="../../frontend/css/login.css">
</head>
<body>

<div class="box">

    <div class="logo-symbol">𖠋♡𖠋</div>

    <h2>Iniciar sesión</h2>

    <form method="POST">
        <input type="email" name="email" placeholder="Correo">
        <input type="password" name="password" placeholder="Contraseña">
        <button type="submit">Entrar</button>
    </form>

    <div class="msg">
        <?php echo $mensaje; ?>
    </div>

    <p class="link">
        ¿No tienes cuenta? <a href="registro.php">Crear cuenta</a>
    </p>

</div>

</body>
</html>
