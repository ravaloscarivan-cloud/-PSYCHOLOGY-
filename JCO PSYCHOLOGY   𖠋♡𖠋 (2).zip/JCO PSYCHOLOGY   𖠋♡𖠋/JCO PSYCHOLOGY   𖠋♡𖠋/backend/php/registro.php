<?php
require "config.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST["nombre"] ?? "");
    $email  = trim($_POST["correo"] ?? "");
    $pass   = $_POST["password"] ?? "";

    if ($nombre === "" || $email === "" || $pass === "") {
        $mensaje = "❌ Todos los campos son obligatorios";
    } else {

        // Verificar si el correo ya existe
        $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $mensaje = "❌ Este correo ya está registrado";
        } else {

            $passwordHash = password_hash($pass, PASSWORD_DEFAULT);

            $sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("sss", $nombre, $email, $passwordHash);

                if ($stmt->execute()) {
                    // REDIRECCIÓN CORRECTA
                    header("Location: login.php");
                    exit;
                } else {
                    $mensaje = "❌ Error al crear la cuenta";
                }

                $stmt->close();
            } else {
                $mensaje = "❌ Error en la consulta SQL";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro | JCO PSYCHOLOGY</title>
    <link rel="stylesheet" href="../../frontend/css/registro.css">
</head>
<body>

<div class="box">

    <div class="logo-symbol">𖠋♡𖠋</div>

    <h2>Crear cuenta</h2>

    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre completo">
        <input type="email" name="correo" placeholder="Correo electrónico">
        <input type="password" name="password" placeholder="Contraseña">
        <button type="submit">Crear cuenta</button>
    </form>

    <div class="msg">
        <?php echo $mensaje; ?>
    </div>

    <p class="link">
        ¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
    </p>

</div>

</body>
</html>
