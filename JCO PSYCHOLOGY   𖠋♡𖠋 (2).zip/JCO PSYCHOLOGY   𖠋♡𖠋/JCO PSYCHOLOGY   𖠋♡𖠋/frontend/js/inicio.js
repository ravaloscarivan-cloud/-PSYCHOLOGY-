document.addEventListener('DOMContentLoaded', () => {
  const navItems = document.querySelectorAll('.nav-item');
  const sections = document.querySelectorAll('.section-container');
  const modal = document.getElementById('modal');
  const modalBody = document.getElementById('modal-body');
  const modalClose = document.getElementById('modal-close');

  function showSection(id) {
    sections.forEach(s => {
      if (s.id === id) {
        s.hidden = false;
        s.scrollIntoView({ behavior: 'smooth', block: 'start' });
        s.classList.add('visible');
      } else {
        s.hidden = true;
        s.classList.remove('visible');
      }
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      const target = item.dataset.target;
      navItems.forEach(i=>i.classList.remove('active'));
      item.classList.add('active');

      if (target === 'inicio') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        // hide all detail sections
        sections.forEach(s => { s.hidden = true; s.classList.remove('visible'); });
        return;
      }

      // show chosen section
      showSection(target);
    });
  });

  // Test emocional handling
  const testForm = document.getElementById('test-form');
  if (testForm) {
    testForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const form = new FormData(testForm);
      const score = ['q1','q2','q3','q4','q5'].reduce((sum,k)=> {
        const val = form.get(k);
        return sum + (val ? parseInt(val, 10) : 0);
      }, 0);
      
      const resultBox = document.getElementById('test-result');
      const resultLevel = document.getElementById('result-level');
      const resultMessage = document.getElementById('result-message');
      const resultActions = document.getElementById('result-actions');
      
      let level = 'Bajo';
      let message = '';
      let actions = '';
      let color = '#2ecc71';

      if (score >= 8) {
        level = 'Alto';
        message = 'Puntuación: ' + score + '/10. Parece que atraviesas un momento difícil. Te recomendamos encarecidamente buscar apoyo profesional.';
        actions = '<h4>Acciones sugeridas:</h4><ul><li>✓ Contacta a un psicólogo certificado</li><li>✓ Habla con alguien de confianza hoy</li><li>✓ Practica técnicas de relajación (respiración, meditación)</li></ul>';
        color = '#e74c3c';
      } else if (score >= 5) {
        level = 'Medio';
        message = 'Puntuación: ' + score + '/10. Tienes algunos desafíos emocionales. Es buen momento para cuidarte más y considerar apoyo.';
        actions = '<h4>Acciones sugeridas:</h4><ul><li>✓ Establece una rutina de autocuidado diaria</li><li>✓ Practica ejercicio físico 3x/semana</li><li>✓ Busca apoyo de amigos o familia</li></ul>';
        color = '#f39c12';
      } else {
        level = 'Bajo';
        message = 'Puntuación: ' + score + '/10. ¡Buen trabajo! Tu bienestar emocional está en buen estado. Sigue cuidando de ti.';
        actions = '<h4>Para mantener el bienestar:</h4><ul><li>✓ Continúa con tus hábitos saludables</li><li>✓ Practica mindfulness o meditación</li><li>✓ Mantén conexión con gente que te importa</li></ul>';
        color = '#2ecc71';
      }

      resultLevel.innerHTML = `Resultado: <strong>${level}</strong>`;
      resultLevel.style.color = color;
      resultMessage.textContent = message;
      resultActions.innerHTML = actions;
      
      resultBox.hidden = false;
      resultBox.style.borderLeftColor = color;
      resultBox.scrollIntoView({behavior:'smooth'});
    });
  }

  // Quick chat buttons open modal with preset messages
  document.querySelectorAll('.quick').forEach(btn => {
    btn.addEventListener('click', () => {
      const preset = btn.dataset.preset;
      let message = '';
      if (preset === 'ansioso') message = 'Siento mucha ansiedad, necesito ejercicios para calmarme.';
      if (preset === 'triste') message = 'Me siento triste y sin ganas.';
      if (preset === 'insomnio') message = 'No puedo dormir, ¿qué puedo hacer ahora?';
      if (preset === 'estresado') message = 'Estoy estresado y necesito bajar la tensión.';

      modalBody.innerHTML = `<h3>Iniciar conversación</h3><p>${message}</p><button id='start-ia' class='btn'>Hablar con la Asistente IA</button>`;
      modal.hidden = false; modal.setAttribute('aria-hidden','false');
    });
  });

  // Modal close
  if (modalClose) modalClose.addEventListener('click', () => { modal.hidden = true; modal.setAttribute('aria-hidden','true'); });
  modal.addEventListener('click', (e) => { if (e.target === modal) { modal.hidden = true; modal.setAttribute('aria-hidden','true'); } });
});
