// Chat IA functionality with API integration ready
// Currently simulated; ready for API connection

class ChatIA {
  constructor() {
    this.apiEndpoint = null; // Set to your API endpoint: 'https://api.ejemplo.com/chat'
    this.messages = [];
    this.chatBox = document.getElementById('chat-box');
    this.chatMessages = document.getElementById('chat-messages');
    this.chatForm = document.getElementById('chat-form');
    this.chatInput = document.getElementById('chat-input');
    this.init();
  }

  init() {
    if (this.chatForm) {
      this.chatForm.addEventListener('submit', (e) => this.handleSend(e));
    }
  }

  handleSend(e) {
    e.preventDefault();
    const message = this.chatInput.value.trim();
    if (!message) return;

    // Add user message
    this.addMessage(message, 'user');
    this.chatInput.value = '';

    // Get AI response
    this.getResponse(message);
  }

  addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.innerHTML = `<p>${this.escapeHtml(text)}</p>`;
    this.chatMessages.appendChild(messageDiv);
    this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
  }

  async getResponse(userMessage) {
    // Show typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.innerHTML = '<p>La IA está escribiendo...</p>';
    this.chatMessages.appendChild(typingDiv);

    let response = '';

    if (this.apiEndpoint) {
      // Real API call
      response = await this.callAPI(userMessage);
    } else {
      // Simulated responses (until API is configured)
      response = this.getSimulatedResponse(userMessage);
    }

    // Remove typing indicator
    typingDiv.remove();

    // Add AI response
    this.addMessage(response, 'bot');
    this.messages.push({ user: userMessage, bot: response });
  }

  async callAPI(message) {
    try {
      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: message,
          context: this.messages,
          user_preset: window.currentChatPreset || null
        })
      });

      if (!response.ok) throw new Error('API error');
      const data = await response.json();
      return data.response || 'Hubo un error. Intenta de nuevo.';
    } catch (error) {
      console.error('Chat API error:', error);
      return 'Lo siento, no puedo conectar con el servidor en este momento. Intenta más tarde.';
    }
  }

  getSimulatedResponse(message) {
    const responses = {
      ansiedad: {
        questions: ['ansiedad', 'ansioso', 'palpitaciones', 'respiración', 'miedo', 'pánico'],
        replies: [
          'Entiendo que la ansiedad es difícil. Respira profundo: inhala 4 segundos, exhala 8. Esto activará tu sistema calmante.',
          'La ansiedad es real, pero temporal. ¿Qué te ayuda normalmente a relajarte?',
          'Tecnica 5-4-3-2-1: Nombra 5 cosas que VES, 4 que TOCAS, 3 que OYES, 2 que HUELES, 1 que SABOREAS. Te ancla en el presente.',
          '¿Desde cuándo sientes esta ansiedad? A veces hablar del origen ayuda.'
        ]
      },
      triste: {
        questions: ['triste', 'tristeza', 'deprimido', 'depresión', 'vacio', 'sin ganas'],
        replies: [
          'Siento que te sientas triste. Eso es válido y real. ¿Quieres hablar sobre qué te hace sentir así?',
          'La tristeza es parte de la vida. Pero si persiste, considera hablar con un profesional.',
          'Pequeños pasos: levántate, camina 10 min, toma agua. Después, algo que te guste un poco.',
          '¿Hay algo que normalmente te anima? Aunque sea pequeño, ayuda.'
        ]
      },
      insomnio: {
        questions: ['dormir', 'sueño', 'insomnio', 'duermo', 'despierto', 'noche'],
        replies: [
          'El sueño es crucial. ¿Cuántas horas duermes? ¿A qué hora intentas acostarte?',
          'Evita pantallas 1 hora antes de dormir. La luz azul despierta el cerebro.',
          'Técnica: Relajación progresiva. Tensa y relaja cada grupo muscular de pies a cabeza.',
          'Un té de manzanilla o valeriana antes de dormir puede ayudar. ¿Qué has probado?'
        ]
      },
      estresado: {
        questions: ['estresado', 'estrés', 'agobiado', 'presión', 'saturado', 'abrumado'],
        replies: [
          'El estrés abruma, pero es temporal. Toma un respiro profundo. ¿Qué causa el estrés?',
          'Rutina de 10 min: estira 1 min, respira profundo 3 min, muévete 3 min, visualiza 2 min.',
          '¿Puedes delegar algo? A veces la carga es demasiada para una persona.',
          'Recuerda: No puedes controlar todo, pero sí tu respuesta. ¿Qué está en tu control?'
        ]
      },
      default: [
        'Entiendo. Cuéntame un poco más si quieres. Estoy aquí para escuchar.',
        '¿Hay algo específico que te preocupe en este momento?',
        'La salud mental es un viaje. Gracias por compartir conmigo.',
        '¿Hay algún recurso o técnica que quieras que te enseñe?',
        'Recuerda: buscar ayuda es un signo de fortaleza, no debilidad.'
      ]
    };

    const lowerMessage = message.toLowerCase();
    
    // Check preset context
    if (window.currentChatPreset) {
      const presetResponses = responses[window.currentChatPreset];
      if (presetResponses && presetResponses.replies) {
        return presetResponses.replies[Math.floor(Math.random() * presetResponses.replies.length)];
      }
    }

    // Check message keywords
    for (const [key, data] of Object.entries(responses)) {
      if (key !== 'default' && data.questions) {
        if (data.questions.some(q => lowerMessage.includes(q))) {
          return data.replies[Math.floor(Math.random() * data.replies.length)];
        }
      }
    }

    // Default responses
    return responses.default[Math.floor(Math.random() * responses.default.length)];
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  setAPIEndpoint(endpoint) {
    this.apiEndpoint = endpoint;
  }
}

// Initialize chat
const chatIA = new ChatIA();

// Quick buttons handling
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.quick').forEach(btn => {
    btn.addEventListener('click', () => {
      const preset = btn.dataset.preset;
      window.currentChatPreset = preset;
      
      // Navigate to chat section
      const chatSection = document.getElementById('chat-ia');
      if (chatSection) {
        chatSection.hidden = false;
        chatSection.scrollIntoView({ behavior: 'smooth' });
      }

      // Initial message based on preset
      const presetMessages = {
        ansioso: '¿Qué tipo de ansiedad sientes?',
        triste: '¿Quieres hablar sobre qué te hace sentir triste?',
        insomnio: '¿Cuándo empezó tu problema de sueño?',
        estresado: '¿Qué es lo que más te estresa en este momento?'
      };

      setTimeout(() => {
        chatIA.addMessage(presetMessages[preset] || 'Estoy aquí para ayudarte.', 'bot');
      }, 300);
    });
  });
});

// Export for API configuration
window.ChatIA = ChatIA;
window.chatIA = chatIA;
