const form = document.getElementById("registerForm");
const msg = document.getElementById("msg");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(form);

    fetch("../../backend/php/registro.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        console.log(data); // 👈 MUY IMPORTANTE

        if (data === "OK") {
            msg.textContent = "✅ Cuenta creada correctamente. Redirigiendo...";
            msg.style.color = "#00c896";

            setTimeout(() => {
                window.location.href = "inisesion.html";
            }, 1500);

        } else if (data === "EXISTE") {
            msg.textContent = "❌ Este correo ya está registrado";
            msg.style.color = "red";

        } else if (data === "VACIO") {
            msg.textContent = "❌ Completa todos los campos";
            msg.style.color = "red";

        } else {
            msg.textContent = "❌ Error al crear la cuenta";
            msg.style.color = "red";
        }
    });
});
