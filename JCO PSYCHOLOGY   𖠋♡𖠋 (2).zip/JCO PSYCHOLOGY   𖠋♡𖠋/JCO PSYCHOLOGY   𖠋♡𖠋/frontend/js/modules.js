// Módulos Avanzados: Depresión, Soledad, Apoyo

document.addEventListener('DOMContentLoaded', function() {
    initializeModules();
});

// Inicializar módulos
function initializeModules() {
    setupCardClickHandlers();
    setupModuleButtons();
    setupBackButtons();
    setupDepressionLogic();
    setupLonelinessLogic();
    setupSupportLogic();
}

// Manejar clicks en tarjetas
function setupCardClickHandlers() {
    document.querySelectorAll('.card[data-module]').forEach(card => {
        card.style.cursor = 'pointer';
        card.addEventListener('click', function(e) {
            if (e.target.classList.contains('card-btn') || e.target.closest('.card-btn')) {
                const module = this.getAttribute('data-module');
                openModule(module);
            }
        });
    });
}

// Abrir módulo
function openModule(module) {
    // Ocultar todas las secciones
    document.querySelectorAll('.section-container').forEach(section => {
        section.hidden = true;
    });
    
    // Mostrar módulo específico
    const moduleId = module === 'depression' ? 'depression-module' :
                     module === 'loneliness' ? 'loneliness-module' : 'support-module';
    
    const moduleElement = document.getElementById(moduleId);
    if (moduleElement) {
        moduleElement.hidden = false;
        moduleElement.scrollIntoView({ behavior: 'smooth' });
    }
}

// Cerrar módulo
function closeModule() {
    document.querySelectorAll('.module-section').forEach(section => {
        section.hidden = true;
    });
    document.getElementById('inicio').hidden = false;
    document.getElementById('inicio').scrollIntoView({ behavior: 'smooth' });
}

// Setup botones de módulo
function setupModuleButtons() {
    document.querySelectorAll('.module-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            showModuleContent(action);
        });
    });
}

// Mostrar contenido del módulo
function showModuleContent(action) {
    // Ocultar todos los contenidos
    document.querySelectorAll('.module-content').forEach(content => {
        content.hidden = true;
    });
    
    // Mostrar contenido específico
    const contentId = action + '-content';
    const contentElement = document.getElementById(contentId);
    if (contentElement) {
        contentElement.hidden = false;
        contentElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Setup botones back
function setupBackButtons() {
    document.querySelectorAll('.btn-back').forEach(btn => {
        btn.addEventListener('click', closeModule);
    });
}

// ==================== LÓGICA DE DEPRESIÓN ====================
function setupDepressionLogic() {
    // Test de depresión
    const depressionForm = document.getElementById('depression-form');
    if (depressionForm) {
        depressionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            calculateDepressionScore();
        });
    }

    // Reformulación de pensamientos
    const reformulateBtn = document.getElementById('reformulate-btn');
    if (reformulateBtn) {
        reformulateBtn.addEventListener('click', reformulateThought);
    }

    // Marcar activación
    const markActivation = document.getElementById('mark-activation');
    if (markActivation) {
        markActivation.addEventListener('click', function() {
            alert('¡Excelente! Acabas de dar un paso importante. Felicidades 🎉');
        });
    }

    // Rutina anti-bajón
    document.querySelectorAll('#depression-tools-content input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', updateRoutineProgress);
    });
}

// Calcular puntuación de depresión
function calculateDepressionScore() {
    const form = document.getElementById('depression-form');
    const formData = new FormData(form);
    let score = 0;

    for (let [key, value] of formData) {
        score += parseInt(value);
    }

    const resultBox = document.getElementById('depression-result');
    let resultHTML = '';

    if (score <= 10) {
        resultBox.classList.remove('medium-risk', 'high-risk');
        resultHTML = `
            <h4>✅ Resultado: Síntomas Leves</h4>
            <p>Tu puntuación sugiere síntomas leves o ausentes de depresión.</p>
            <p><strong>Recomendación:</strong> Continúa cuidando tu bienestar emocional con ejercicio, conexión social y actividades que disfrutes.</p>
        `;
    } else if (score <= 20) {
        resultBox.classList.add('medium-risk');
        resultHTML = `
            <h4>⚠️ Resultado: Síntomas Moderados</h4>
            <p>Tu puntuación sugiere síntomas moderados. Considera hablar con alguien de confianza.</p>
            <p><strong>Recomendación:</strong> Usa las herramientas aquí disponibles y considera buscar apoyo profesional si persisten.</p>
        `;
    } else {
        resultBox.classList.add('high-risk');
        resultHTML = `
            <h4>🚨 Resultado: Síntomas Severos</h4>
            <p>Tu puntuación sugiere síntomas significativos de depresión.</p>
            <p><strong>Acción inmediata recomendada:</strong> Por favor, habla con un profesional de salud mental o contacta una línea de crisis.</p>
            <button class="btn" onclick="document.getElementById('talk-professional').click()">Buscar Ayuda Profesional</button>
        `;
    }

    resultBox.innerHTML = resultHTML;
    resultBox.hidden = false;
}

// Reformular pensamiento negativo
function reformulateThought() {
    const thoughtInput = document.getElementById('negative-thought');
    const thought = thoughtInput.value.trim();

    if (!thought) {
        alert('Por favor, escribe un pensamiento negativo.');
        return;
    }

    const resultBox = document.getElementById('reformulation-result');
    const reformulations = [
        { pattern: /nunca|jamás/i, suggestion: 'Cambiar "nunca" por "todavía no" o "en este momento"' },
        { pattern: /siempre|todo/i, suggestion: 'Reconocer excepciones: ¿hay veces que no es así?' },
        { pattern: /no puedo|imposible/i, suggestion: 'Preguntar: ¿Qué necesitaría para poder hacerlo?' },
        { pattern: /soy fracaso|incompetente/i, suggestion: 'Reconocer tus logros, aunque sean pequeños' },
        { pattern: /me odiaria|no valgo|inútil/i, suggestion: 'Tratarte como lo harías con un amigo' }
    ];

    let suggestion = 'Tu mente está interpretando esta situación. Pregúntate: ¿Es esto totalmente cierto? ¿Hay otras formas de verlo?';
    
    for (let ref of reformulations) {
        if (ref.pattern.test(thought)) {
            suggestion = ref.suggestion;
            break;
        }
    }

    resultBox.innerHTML = `
        <h4>💭 Reformulación de tu pensamiento:</h4>
        <p><strong>Pensamiento original:</strong> "${thought}"</p>
        <p><strong>Reformulación:</strong> ${suggestion}</p>
        <p><strong>Pregunta reflexiva:</strong> ¿Qué evidencia tengo de que esto es completamente cierto?</p>
    `;
    resultBox.hidden = false;
}

// Actualizar progreso de rutina
function updateRoutineProgress() {
    const checkboxes = document.querySelectorAll('#depression-tools-content input[type="checkbox"]');
    const checked = Array.from(checkboxes).filter(cb => cb.checked).length;
    document.getElementById('routine-progress').textContent = `Completadas: ${checked}/3`;
}

// ==================== LÓGICA DE SOLEDAD ====================
function setupLonelinessLogic() {
    // Chat de soledad
    const lonelinessForm = document.getElementById('loneliness-chat-form');
    if (lonelinessForm) {
        lonelinessForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLonelinessChat(this);
        });
    }

    // Plan de 4 días
    document.querySelectorAll('.day-check').forEach(checkbox => {
        checkbox.addEventListener('change', updatePlanProgress);
    });

    // Agregar conexión
    document.getElementById('add-connection')?.addEventListener('click', addConnectionItem);
}

// Manejar chat de soledad
function handleLonelinessChat(form) {
    const input = form.querySelector('.chat-input');
    const message = input.value.trim();

    if (!message) return;

    const chatMessages = document.getElementById('loneliness-chat-messages');

    // Agregar mensaje del usuario
    const userMsg = document.createElement('div');
    userMsg.className = 'message user-message';
    userMsg.innerHTML = `<p>${escapeHtml(message)}</p>`;
    chatMessages.appendChild(userMsg);

    // Respuesta empática
    const responses = [
        "Entiendo lo que sientes. No estás solo en esto. 💙",
        "Gracias por compartir. Tu sentimiento es válido y importante.",
        "Eres más fuerte de lo que crees. Estoy aquí para acompañarte.",
        "La soledad duele, pero significa que tu corazón está buscando conexión. Eso es hermoso.",
        "No tienes que enfrentar esto solo. Aquí estoy, escuchándote.",
        "Tus sentimientos importan. Mereces amor y compañía.",
        "Está bien sentirse solo a veces. Lo importante es que no dejes de intentar conectar."
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    setTimeout(() => {
        const botMsg = document.createElement('div');
        botMsg.className = 'message bot-message';
        botMsg.innerHTML = `<p>${randomResponse}</p>`;
        chatMessages.appendChild(botMsg);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 500);

    input.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Actualizar progreso del plan
function updatePlanProgress() {
    const checkboxes = document.querySelectorAll('.day-check');
    const checked = Array.from(checkboxes).filter(cb => cb.checked).length;
    document.getElementById('plan-progress').textContent = `Avance: ${checked}/4 completados`;
}

// Agregar item de conexión
function addConnectionItem() {
    const input = document.querySelector('.connection-input');
    const value = input.value.trim();

    if (!value) {
        alert('Por favor escribe algo');
        return;
    }

    const list = document.getElementById('connection-list');
    const item = document.createElement('div');
    item.className = 'connection-item';
    item.innerHTML = `
        <p>✓ ${escapeHtml(value)}</p>
        <button class="btn-remove" onclick="this.parentElement.remove()">Eliminar</button>
    `;
    list.insertBefore(item, input);
    input.value = '';
}

// ==================== LÓGICA DE APOYO ====================
function setupSupportLogic() {
    // Respiración guiada
    document.getElementById('start-breathing')?.addEventListener('click', startBreathingExercise);

    // Grounding
    document.getElementById('start-grounding')?.addEventListener('click', startGroundingExercise);

    // Meditación
    document.getElementById('start-meditation')?.addEventListener('click', startMeditation);

    // Crisis breathing
    document.getElementById('crisis-breathe')?.addEventListener('click', crisisBreathing);
}

// Ejercicio de respiración
function startBreathingExercise() {
    alert('Ejercicio de Respiración 4-7-8:\n\n1. Inhala durante 4 segundos\n2. Sostén durante 7 segundos\n3. Exhala durante 8 segundos\n4. Repite 4 veces\n\nVamos a comenzar cuando cierres esto. Prepárate.');
    
    const steps = [
        { time: 4, text: 'INHALA (1-2-3-4)' },
        { time: 7, text: 'SOSTÉN (1-2-3-4-5-6-7)' },
        { time: 8, text: 'EXHALA (1-2-3-4-5-6-7-8)' }
    ];

    let round = 1;
    function runRound() {
        if (round > 4) {
            alert('¡Excelente! Completaste el ejercicio. Deberías sentirte más calmado.');
            return;
        }

        let stepIndex = 0;
        function nextStep() {
            if (stepIndex >= steps.length) {
                round++;
                setTimeout(runRound, 1000);
                return;
            }
            const step = steps[stepIndex];
            alert(`Ronda ${round}/4\n\n${step.text}`);
            stepIndex++;
            setTimeout(nextStep, step.time * 1000);
        }
        nextStep();
    }
    runRound();
}

// Grounding
function startGroundingExercise() {
    alert('Técnica 5-4-3-2-1 de Grounding:\n\nIdentifica:\n5 cosas que ves\n4 cosas que puedes tocar\n3 cosas que escuchas\n2 cosas que hueles\n1 cosa que pruebas\n\nTómate tu tiempo. Esto te conecta con el presente.');
}

// Meditación
function startMeditation() {
    alert('Meditación Guiada:\n\n"Eres seguro en este momento. Tu cuerpo está protegido. Con cada respiración, la calma entra. Con cada exhalación, la tensión sale. Tu mente se vuelve clara. Tu corazón está en paz. Estás exactamente donde necesitas estar."\n\nLee esto lentamente. Repítelo 3 veces.');
}

// Crisis breathing
function crisisBreathing() {
    alert('RESPIRA CONMIGO:\n\n1. Inhala profundo (1-2-3-4-5)\n2. Sostén (1-2-3-4-5)\n3. Exhala lentamente (1-2-3-4-5-6-7-8)\n\nRepite esto 5 veces.\n\nRecuerda: Esto pasará. Eres fuerte. ¡Respira!');
}

// Utilidades
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function copyToClipboard(button) {
    const text = button.previousElementSibling.querySelector('.template-text p').textContent;
    navigator.clipboard.writeText(text).then(() => {
        const originalText = button.textContent;
        button.textContent = '✓ Copiado';
        setTimeout(() => {
            button.textContent = originalText;
        }, 2000);
    });
}

// Hacer que las tarjetas sean clickeables en su totalidad
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.card[data-module]').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});
