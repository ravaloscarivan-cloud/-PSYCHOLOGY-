// Menu enhancement: animated indicator, keyboard nav, section transitions
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('.menu');
  const navItems = Array.from(document.querySelectorAll('.nav-item'));
  if (!nav || navItems.length === 0) return;
  // add indicator element if not present
  let indicator = nav.querySelector('.nav-indicator');
  if (!indicator) {
    indicator = document.createElement('span');
    indicator.className = 'nav-indicator';
    nav.appendChild(indicator);
  }

  function placeIndicatorOn(el) {
    const rect = el.getBoundingClientRect();
    const parentRect = nav.getBoundingClientRect();
    const left = rect.left - parentRect.left + (rect.width - 60)/2;
    const width = Math.min(rect.width, 140);
    indicator.style.left = `${left}px`;
    indicator.style.width = `${width}px`;
    indicator.style.opacity = '1';
  }

  // initialize on active or first
  const active = nav.querySelector('.nav-item.active') || navItems[0];
  active.classList.add('active');
  placeIndicatorOn(active);

  // resize handler
  window.addEventListener('resize', () => placeIndicatorOn(document.querySelector('.nav-item.active')));

  // click handling and keyboard support
  navItems.forEach((item, idx) => {
    item.setAttribute('tabindex', '0');
    item.addEventListener('click', () => {
      navItems.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      placeIndicatorOn(item);
      // scroll/show section via existing inicio.js nav handling (trigger click behavior)
      item.dispatchEvent(new Event('menu-select'));
    });

    item.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { item.click(); e.preventDefault(); }
      if (e.key === 'ArrowRight') { navItems[(idx+1)%navItems.length].focus(); }
      if (e.key === 'ArrowLeft') { navItems[(idx-1+navItems.length)%navItems.length].focus(); }
    });

    // custom event to bridge to existing showSection logic
    item.addEventListener('menu-select', () => {
      const target = item.dataset.target;
      // trigger the existing nav click listener in inicio.js by calling its logic
      // fallback: scroll to top for 'inicio' or toggle sections
      if (target === 'inicio') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        document.querySelectorAll('.section-container').forEach(s => { s.hidden = true; s.classList.remove('visible'); });
        return;
      }
      document.querySelectorAll('.section-container').forEach(s => {
        if (s.id === target) { s.hidden = false; s.classList.add('enter'); setTimeout(()=> s.classList.add('visible'), 40); s.scrollIntoView({ behavior: 'smooth' }); }
        else { s.classList.remove('visible'); s.hidden = true; }
      });
    });
  });

  // toggle scrolled class when page scrolls
  const onScroll = () => {
    if (window.scrollY > 20) nav.classList.add('scrolled'); else nav.classList.remove('scrolled');
  };
  window.addEventListener('scroll', onScroll);
  onScroll();
});
