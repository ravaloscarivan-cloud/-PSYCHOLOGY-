// Enhanced animations for page load and scroll
document.addEventListener('DOMContentLoaded', () => {
  // Observador para animar elementos cuando entran en viewport
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Observe all fade sections
  document.querySelectorAll('.fade-section, .tema, .card').forEach(el => {
    observer.observe(el);
  });

  // Parallax effect on scroll
  const parallaxElements = document.querySelectorAll('.parallax');
  if (parallaxElements.length > 0) {
    window.addEventListener('scroll', () => {
      parallaxElements.forEach(el => {
        const scrollPosition = window.pageYOffset;
        el.style.backgroundPosition = `center ${scrollPosition * 0.5}px`;
      });
    });
  }

  // Smooth scroll on internal links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Add ripple effect to buttons
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;

      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      ripple.classList.add('ripple');

      this.appendChild(ripple);

      setTimeout(() => ripple.remove(), 600);
    });
  });
});

// CSS for ripple effect (inject dynamically)
const style = document.createElement('style');
style.textContent = `
  .btn {
    position: relative;
    overflow: hidden;
  }

  .ripple {
    position: absolute;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    transform: scale(0);
    animation: ripple-animation 0.6s ease-out;
    pointer-events: none;
  }

  @keyframes ripple-animation {
    to {
      transform: scale(4);
      opacity: 0;
    }
  }

  .fade-section {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s cubic-bezier(0.2, 0.9, 0.2, 1);
  }

  .fade-section.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .card {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s ease backwards;
  }

  .card.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .tema {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s ease backwards;
  }

  .tema.visible {
    opacity: 1;
    transform: translateY(0);
  }
`;
document.head.appendChild(style);
