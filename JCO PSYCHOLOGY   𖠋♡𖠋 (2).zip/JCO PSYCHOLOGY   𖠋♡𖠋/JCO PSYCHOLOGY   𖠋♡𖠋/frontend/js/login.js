const form = document.getElementById("loginForm");
const msg = document.getElementById("msg");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(form);

  fetch("../backend/php/login.php", {
    method: "POST",
    body: formData
})

    .then(res => res.text())
    .then(data => {

        if (data === "OK") {
            msg.textContent = "✅ Inicio de sesión exitoso";
            msg.style.color = "#00c896";

            setTimeout(() => {
                window.location.href = "index.html"; // 👈 AQUÍ CAMBIA
            }, 1200);

        } else if (data === "CONTRASEÑA_INCORRECTA") {
            msg.textContent = "❌ Contraseña incorrecta";
            msg.style.color = "red";

        } else if (data === "NO_EXISTE") {
            msg.textContent = "❌ El usuario no existe";
            msg.style.color = "red";

        } else {
            msg.textContent = "❌ Error inesperado";
            msg.style.color = "red";
        }
    })
    .catch(() => {
        msg.textContent = "❌ Error de conexión con el servidor";
        msg.style.color = "red";
    });
});

function googleLogin() {
    window.location.href = "https://accounts.google.com/";
}
