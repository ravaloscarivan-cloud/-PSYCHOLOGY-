// ========================================
// GRÁFICAS INTERACTIVAS CON CHART.JS
// ========================================

// Configuración global de Chart.js
Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
Chart.defaults.color = '#666';

// GRÁFICA 1: Prevalencia de Depresión Global
const depressionCtx = document.getElementById('depressionChart').getContext('2d');
new Chart(depressionCtx, {
    type: 'doughnut',
    data: {
        labels: ['Con depresión', 'Sin depresión'],
        datasets: [{
            data: [5, 95],
            backgroundColor: [
                'rgba(102, 126, 234, 0.8)',
                'rgba(200, 200, 200, 0.2)'
            ],
            borderColor: [
                'rgba(102, 126, 234, 1)',
                'rgba(200, 200, 200, 1)'
            ],
            borderWidth: 3,
            hoverOffset: 10
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 20,
                    font: { size: 14, weight: 'bold' }
                }
            }
        }
    }
});

// GRÁFICA 2: Ansiedad por Edad
const anxietyCtx = document.getElementById('anxietyChart').getContext('2d');
new Chart(anxietyCtx, {
    type: 'bar',
    data: {
        labels: ['18-25', '26-35', '36-45', '46-55', '56-65', '+65'],
        datasets: [{
            label: 'Prevalencia de Ansiedad (%)',
            data: [24, 20, 18, 16, 14, 12],
            backgroundColor: [
                'rgba(240, 147, 251, 0.8)',
                'rgba(240, 147, 251, 0.7)',
                'rgba(240, 147, 251, 0.6)',
                'rgba(240, 147, 251, 0.5)',
                'rgba(240, 147, 251, 0.4)',
                'rgba(240, 147, 251, 0.3)'
            ],
            borderColor: 'rgba(240, 147, 251, 1)',
            borderWidth: 2,
            borderRadius: 8,
            hoverBackgroundColor: 'rgba(240, 147, 251, 1)'
        }]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    font: { size: 13, weight: 'bold' }
                }
            }
        },
        scales: {
            x: {
                max: 30,
                ticks: {
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        }
    }
});

// GRÁFICA 3: Soledad por Grupos Demográficos
const lonelinessCtx = document.getElementById('lonelinessChart').getContext('2d');
new Chart(lonelinessCtx, {
    type: 'radar',
    data: {
        labels: ['Jóvenes\n(18-30)', 'Adultos\n(31-45)', 'Adultos\n(46-60)', 'Mayores\n(+60)', 'Parejas\nAisladas'],
        datasets: [{
            label: 'Soledad (%)',
            data: [32, 26, 22, 28, 24],
            borderColor: 'rgba(79, 172, 254, 1)',
            backgroundColor: 'rgba(79, 172, 254, 0.2)',
            borderWidth: 3,
            fill: true,
            pointRadius: 6,
            pointBackgroundColor: 'rgba(79, 172, 254, 1)',
            pointHoverRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    font: { size: 13, weight: 'bold' }
                }
            }
        },
        scales: {
            r: {
                max: 40,
                ticks: {
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        }
    }
});

// GRÁFICA 4: Estrés Laboral por Sector
const stressCtx = document.getElementById('stressChart').getContext('2d');
new Chart(stressCtx, {
    type: 'horizontalBar',
    type: 'bar',
    data: {
        labels: ['Salud', 'Educación', 'Tecnología', 'Finanzas', 'Manufactura', 'Retail'],
        datasets: [{
            label: 'Estrés Laboral (%)',
            data: [78, 72, 68, 65, 58, 52],
            backgroundColor: [
                'rgba(67, 233, 123, 0.8)',
                'rgba(67, 233, 123, 0.7)',
                'rgba(67, 233, 123, 0.6)',
                'rgba(67, 233, 123, 0.5)',
                'rgba(67, 233, 123, 0.4)',
                'rgba(67, 233, 123, 0.3)'
            ],
            borderColor: 'rgba(67, 233, 123, 1)',
            borderWidth: 2,
            borderRadius: 8
        }]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    font: { size: 13, weight: 'bold' }
                }
            }
        },
        scales: {
            x: {
                max: 100,
                ticks: {
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        }
    }
});

// GRÁFICA 5: Factores de Riesgo
const riskCtx = document.getElementById('riskFactorsChart').getContext('2d');
new Chart(riskCtx, {
    type: 'bubble',
    data: {
        datasets: [
            {
                label: 'Problemas Económicos',
                data: [{x: 85, y: 70, r: 20}],
                backgroundColor: 'rgba(250, 112, 154, 0.6)',
                borderColor: 'rgba(250, 112, 154, 1)',
                borderWidth: 2
            },
            {
                label: 'Relaciones Sociales',
                data: [{x: 75, y: 80, r: 18}],
                backgroundColor: 'rgba(250, 165, 87, 0.6)',
                borderColor: 'rgba(250, 165, 87, 1)',
                borderWidth: 2
            },
            {
                label: 'Situación Laboral',
                data: [{x: 70, y: 75, r: 19}],
                backgroundColor: 'rgba(254, 202, 87, 0.6)',
                borderColor: 'rgba(254, 202, 87, 1)',
                borderWidth: 2
            },
            {
                label: 'Salud Física',
                data: [{x: 65, y: 60, r: 17}],
                backgroundColor: 'rgba(84, 160, 255, 0.6)',
                borderColor: 'rgba(84, 160, 255, 1)',
                borderWidth: 2
            },
            {
                label: 'Entorno Familiar',
                data: [{x: 80, y: 65, r: 16}],
                backgroundColor: 'rgba(102, 126, 234, 0.6)',
                borderColor: 'rgba(102, 126, 234, 1)',
                borderWidth: 2
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    font: { size: 12, weight: 'bold' }
                }
            }
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Prevalencia (%)'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Impacto en Salud Mental (%)'
                }
            }
        }
    }
});

// GRÁFICA 6: Acceso a Tratamiento
const treatmentCtx = document.getElementById('treatmentChart').getContext('2d');
new Chart(treatmentCtx, {
    type: 'line',
    data: {
        labels: ['Países\nAltos Ingresos', 'Países\nIngresos Medios', 'Países\nBajos Ingresos'],
        datasets: [{
            label: 'Con Acceso a Tratamiento (%)',
            data: [65, 35, 8],
            borderColor: 'rgba(255, 99, 72, 1)',
            backgroundColor: 'rgba(255, 99, 72, 0.1)',
            borderWidth: 3,
            fill: true,
            pointRadius: 8,
            pointBackgroundColor: 'rgba(255, 99, 72, 1)',
            pointHoverRadius: 10,
            pointBorderColor: 'white',
            pointBorderWidth: 2,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    font: { size: 13, weight: 'bold' }
                }
            }
        },
        scales: {
            y: {
                max: 100,
                ticks: {
                    callback: function(value) {
                        return value + '%';
                    }
                }
            }
        }
    }
});

// GRÁFICA 7: Tasa de Mejoría
const recoveryCtx = document.getElementById('recoveryChart').getContext('2d');
new Chart(recoveryCtx, {
    type: 'doughnut',
    data: {
        labels: ['Mejora Significativa', 'Mejora Leve', 'Sin Cambio'],
        datasets: [{
            data: [85, 12, 3],
            backgroundColor: [
                'rgba(84, 160, 255, 0.8)',
                'rgba(84, 160, 255, 0.5)',
                'rgba(200, 200, 200, 0.3)'
            ],
            borderColor: [
                'rgba(84, 160, 255, 1)',
                'rgba(84, 160, 255, 1)',
                'rgba(200, 200, 200, 1)'
            ],
            borderWidth: 3,
            hoverOffset: 10
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 20,
                    font: { size: 14, weight: 'bold' }
                }
            }
        }
    }
});

// GRÁFICA 8: Costo Económico
const economicCtx = document.getElementById('economicChart').getContext('2d');
new Chart(economicCtx, {
    type: 'bar',
    data: {
        labels: ['Pérdida de\nProductividad', 'Costos\nMédicos', 'Cuidados\nIndirectos', 'Investigación\nSub-financiada'],
        datasets: [{
            label: 'Costo (Billones USD)',
            data: [0.6, 0.25, 0.1, 0.05],
            backgroundColor: [
                'rgba(240, 112, 154, 0.8)',
                'rgba(250, 165, 87, 0.8)',
                'rgba(254, 202, 87, 0.8)',
                'rgba(102, 126, 234, 0.8)'
            ],
            borderColor: [
                'rgba(240, 112, 154, 1)',
                'rgba(250, 165, 87, 1)',
                'rgba(254, 202, 87, 1)',
                'rgba(102, 126, 234, 1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            hoverBackgroundColor: [
                'rgba(240, 112, 154, 1)',
                'rgba(250, 165, 87, 1)',
                'rgba(254, 202, 87, 1)',
                'rgba(102, 126, 234, 1)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    font: { size: 13, weight: 'bold' }
                }
            }
        },
        scales: {
            y: {
                ticks: {
                    callback: function(value) {
                        return '$' + value + 'T';
                    }
                }
            }
        }
    }
});
