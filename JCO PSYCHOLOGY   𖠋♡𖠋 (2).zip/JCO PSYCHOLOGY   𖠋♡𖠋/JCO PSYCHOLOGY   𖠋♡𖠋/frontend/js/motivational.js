// Mensajes Motivacionales relacionados con psicología y bienestar emocional

const motivationalMessages = [
    // Mensajes sobre aceptación y amor propio
    "Tu valor no se define por lo que otros piensan. Eres suficiente tal como eres.",
    "Aceptar tus emociones es el primer paso para transformarlas.",
    "No necesitas ser perfecto para merecer amor y respeto, especialmente el tuyo.",
    "El amor propio no es vanidad, es supervivencia emocional.",
    "Tus imperfecciones te hacen humano. Y ser humano es lo más hermoso.",
    
    // Mensajes sobre el proceso de sanación
    "La sanación no es lineal. Los altibajos son parte del viaje.",
    "Cada día que enfrentas tus miedos, te vuelves más fuerte.",
    "Es okay no estar bien. Es más okay pedir ayuda.",
    "Sanar toma tiempo. Sé paciente contigo mismo.",
    "Del dolor nace la sabiduría. Tus lucha tienen sentido.",
    
    // Mensajes sobre superación y resiliencia
    "Sobreviviste a cada momento difícil que enfrentaste. Eres más resistente de lo que crees.",
    "La resiliencia no es no caer, es levantarse cada vez que caes.",
    "Tus cicatrices cuentan historias de valentía y supervivencia.",
    "Puedes estar quebrado y seguir siendo valioso.",
    "Lo que no te mata, te enseña. Aprende y crece.",
    
    // Mensajes sobre el presente
    "El único momento que tienes es ahora. Vive en él.",
    "Preocuparse por el futuro no cambia el futuro, solo arruina el presente.",
    "Tu pasado no define tu presente. Tienes el poder de cambiarlo.",
    "Hoy es una nueva oportunidad para elegirte a ti mismo.",
    "Este momento, aquí y ahora, es donde tu poder reside.",
    
    // Mensajes sobre conexión y soledad
    "No estás solo en tu lucha. Millones sienten lo que sientes.",
    "La vulnerabilidad no es debilidad, es el acto más valiente que existe.",
    "Conectar con otros es un acto de valentía y esperanza.",
    "Tu historia puede ser la esperanza de alguien más.",
    "En la comunidad encontramos fuerza. No tienes que hacerlo solo.",
    
    // Mensajes sobre el autocuidado
    "Cuidarte no es egoísmo, es necesario.",
    "Pequeños actos de amor propio generan grandes cambios.",
    "Tu bienestar mental es prioridad. No culpa.",
    "Descansar es productivo. Tu salud mental lo necesita.",
    "Decir 'no' es cuidarte. Es un acto de amor.",
    
    // Mensajes sobre esperanza
    "Las cosas pueden mejorar. La evidencia lo demuestra.",
    "Incluso en la oscuridad más profunda, existe una salida.",
    "Tu situación actual no es tu condición final.",
    "Hay esperanza en este momento. Busca la luz.",
    "El sufrimiento es temporal. La evolución es permanente.",
    
    // Mensajes sobre el crecimiento personal
    "Cada emoción difícil es una oportunidad para crecer.",
    "El crecimiento duele, pero el resultado vale la pena.",
    "Te estás convirtiendo en la persona que necesitabas.",
    "El cambio empieza cuando decides que mereces mejor.",
    "Tu evolución emocional es tu victoria más grande.",
    
    // Mensajes sobre la ansiedad y el miedo
    "La ansiedad miente. La verdad es que eres capaz de manejar esto.",
    "El miedo es información, no una orden. Puedes elegir actuar de todos modos.",
    "Lo que temes raramente ocurre. Confía en ti.",
    "Respira. Esto también pasará.",
    "Tu ansiedad no define quién eres. Es solo lo que sientes.",
    
    // Mensajes finales de motivación
    "Mereces el mismo amor y cuidado que das a otros.",
    "No te rindas. Lo mejor está por venir.",
    "Eres más fuerte de lo que jamás imaginaste.",
    "Tu vida tiene propósito. Sigue adelante.",
    "Hoy es un buen día para elegirte a ti mismo."
];

// Función para obtener un mensaje aleatorio
function getRandomMotivationalMessage() {
    return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
}

// Función para cargar el mensaje motivacional
function loadMotivationalMessage() {
    const textElement = document.getElementById('motivational-text');
    if (textElement) {
        const message = getRandomMotivationalMessage();
        textElement.textContent = message;
        textElement.classList.remove('change-animation');
        // Trigger reflow para que la animación se vuelva a reproducir
        void textElement.offsetWidth;
    }
}

// Cargar mensaje cuando la página carga
document.addEventListener('DOMContentLoaded', loadMotivationalMessage);

// Cambiar mensaje cada vez que se recarga la página (ya está hecho por el evento anterior)

// Opcionalmente: agregar funcionalidad de cambio manual (click en la tarjeta)
document.addEventListener('DOMContentLoaded', function() {
    const card = document.querySelector('.motivational-card');
    if (card) {
        card.addEventListener('click', function() {
            const textElement = document.getElementById('motivational-text');
            textElement.classList.add('change-animation');
            setTimeout(() => {
                const message = getRandomMotivationalMessage();
                textElement.textContent = message;
                textElement.classList.remove('change-animation');
            }, 300);
        });
        card.style.cursor = 'pointer';
    }
});
