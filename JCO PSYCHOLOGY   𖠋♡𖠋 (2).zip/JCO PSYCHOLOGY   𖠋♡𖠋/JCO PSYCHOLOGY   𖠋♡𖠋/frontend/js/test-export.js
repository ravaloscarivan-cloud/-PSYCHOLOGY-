// PDF Export functionality for test results
// Uses jsPDF library (via CDN if not available locally)

window.exportTestResultPDF = function() {
  // Check if jsPDF is available
  if (typeof jsPDF === 'undefined') {
    // Load jsPDF from CDN
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    document.head.appendChild(script);
    script.onload = () => generatePDF();
    return;
  }
  generatePDF();
};

function generatePDF() {
  const { jsPDF } = window.jspdf || {};
  if (!jsPDF) {
    alert('No se pudo cargar la librería PDF. Intenta de nuevo.');
    return;
  }

  const doc = new jsPDF();
  
  // Title
  doc.setFontSize(22);
  doc.text('JCO Psychology', 20, 20);
  doc.setFontSize(14);
  doc.text('Resultado de Test Emocional', 20, 32);
  
  // Date
  doc.setFontSize(10);
  doc.text(`Fecha: ${new Date().toLocaleDateString('es-ES')}`, 20, 42);
  
  // Get result data from DOM
  const resultLevel = document.getElementById('result-level')?.textContent || 'No disponible';
  const resultMessage = document.getElementById('result-message')?.textContent || '';
  
  // Result section
  doc.setFontSize(12);
  doc.text('RESULTADO:', 20, 55);
  doc.setFontSize(14);
  doc.setTextColor(106, 159, 181);
  doc.text(resultLevel, 20, 65);
  
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(11);
  const splitMessage = doc.splitTextToSize(resultMessage, 170);
  doc.text(splitMessage, 20, 75);
  
  // Recommendations section
  let yPos = 95;
  doc.setFontSize(12);
  doc.text('RECOMENDACIONES:', 20, yPos);
  yPos += 10;
  
  doc.setFontSize(10);
  const recommendations = [
    '• Practica técnicas de respiración diaria (5-10 minutos)',
    '• Mantén una rutina de sueño consistente',
    '• Realiza actividad física moderada (30 min, 3x/semana)',
    '• Conecta con alguien de confianza regularmente',
    '• Considera hablar con un profesional de salud mental si necesitas apoyo adicional'
  ];
  
  recommendations.forEach(rec => {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    doc.text(rec, 20, yPos);
    yPos += 8;
  });
  
  // Footer
  yPos += 8;
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Este test es una guía de orientación, no un diagnóstico clínico.', 20, yPos);
  yPos += 4;
  doc.text('Si necesitas ayuda profesional, consulta con un psicólogo certificado.', 20, yPos);
  
  // Save PDF
  doc.save('jco-test-resultado.pdf');
}

// Listen for download button click
document.addEventListener('DOMContentLoaded', () => {
  const downloadBtn = document.getElementById('download-pdf');
  if (downloadBtn) {
    downloadBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.exportTestResultPDF();
    });
  }
});

// Add jsPDF library to HTML if not already loaded
if (!window.jsPDF) {
  const link = document.createElement('script');
  link.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
  document.head.appendChild(link);
}
