# JCO PSYCHOLOGY - Estructura de Archivos Modular

## 📋 Descripción

Se ha reorganizado la estructura del sitio web de JCO PSYCHOLOGY de un único archivo HTML (`inicio.html`) a una estructura **modular con múltiples archivos HTML**, cada uno con su propio CSS y vinculados entre sí.

---

## 📁 Estructura de Carpetas

```
fronted/
├── index.html                    (Página principal - Inicio)
├── sobre-nosotros.html          (Sección: Sobre Nosotros)
├── ayuda-emocional.html         (Sección: Ayuda Emocional)
├── test-emocional.html          (Sección: Test Emocional)
├── contacto.html                (Sección: Contacto)
├── css/
│   ├── style.css                (Estilos base compartidos)
│   ├── sobre-nosotros.css       (Estilos: Sobre Nosotros)
│   ├── ayuda-emocional.css      (Estilos: Ayuda Emocional)
│   ├── test-emocional.css       (Estilos: Test Emocional)
│   ├── contacto.css             (Estilos: Contacto)
│   ├── depression.css           (Estilos: Módulos)
│   ├── loneliness.css           (Estilos: Módulos)
│   ├── support.css              (Estilos: Módulos)
│   ├── chat-ia.css              (Estilos: Chat IA)
│   ├── animations.css           (Animaciones)
│   ├── forms-chat.css           (Formularios y chat)
│   ├── menu-enhancements.css    (Mejoras de menú)
│   ├── modules.css              (Estilos de módulos)
│   └── motivational.css         (Mensajes motivacionales)
├── js/
│   ├── animations.js            (Animaciones)
│   ├── chat-ia.js               (Lógica del chat IA)
│   ├── modules.js               (Lógica de módulos)
│   ├── motivational.js          (Mensajes motivacionales)
│   ├── test-export.js           (Exportar resultados)
│   └── ...otros archivos JS
├── modulos/
│   ├── depression.html          (Módulo: Depresión)
│   ├── loneliness.html          (Módulo: Soledad)
│   ├── support.html             (Módulo: Apoyo)
│   └── chat-ia.html             (Chat con Asistente IA)
└── ...otros archivos
```

---

## 🔗 Navegación Entre Páginas

Todos los archivos HTML contienen la **misma barra de navegación** con enlaces que permiten navegar entre:

- **Inicio** → `index.html`
- **Sobre Nosotros** → `sobre-nosotros.html`
- **Ayuda Emocional** → `ayuda-emocional.html`
- **Test Emocional** → `test-emocional.html`
- **Contacto** → `contacto.html`

### Módulos Avanzados (desde la página de Inicio):

- **Depresión** → `modulos/depression.html`
- **Soledad** → `modulos/loneliness.html`
- **Apoyo** → `modulos/support.html`
- **Chat IA** → `modulos/chat-ia.html`

---

## 📄 Descripción de Archivos HTML

| Archivo | Contenido |
|---------|----------|
| `index.html` | Hero, Cards, Mensaje motivacional |
| `sobre-nosotros.html` | Misión, Visión, Valores, FAQ |
| `ayuda-emocional.html` | Técnicas para Ansiedad, Estrés, Depresión, Soledad, etc. |
| `test-emocional.html` | Test rápido de estado emocional |
| `contacto.html` | Formulario de contacto, Líneas de emergencia |
| `modulos/depression.html` | Test depresión, Herramientas, Recursos |
| `modulos/loneliness.html` | Chat empático, Plan 4 días, Actividades |
| `modulos/support.html` | Recursos, Plantillas, Crisis |
| `modulos/chat-ia.html` | Chat interactivo con IA |

---

## 🎨 Estructura CSS

### Archivo Base: `style.css`
- Estilos compartidos (header, nav, footer, botones, etc.)
- Aplicado a TODOS los archivos HTML

### Archivos Específicos:
- Cada página principal tiene su propio CSS
- Los módulos comparten estilos base

---

## ✨ Características Implementadas

✅ **Navegación consistente** en todas las páginas
✅ **Estructura modular** fácil de mantener
✅ **CSS separado** por sección para mejor organización
✅ **Enlaces entre módulos** funcionan correctamente
✅ **Responsive design** en todas las páginas
✅ **Estilos coherentes** mediante CSS base compartido

---

## 🚀 Cómo Usar

### Para agregar contenido a una sección existente:
1. Edita el archivo HTML correspondiente
2. Asegúrate de mantener la estructura de `<header>`, `<nav>` y `<footer>`

### Para crear una nueva página:
1. Copia uno de los archivos HTML existentes
2. Modifica el contenido `<section>`
3. Crea un CSS específico si es necesario
4. Agrega el enlace en la `<nav>` de todos los archivos

### Para agregar funcionalidad JavaScript:
1. Crea un archivo JS nuevo en la carpeta `js/`
2. Incluye el script al final del `<body>` en el HTML correspondiente

---

## 📝 Notas Importantes

- ⚠️ **Mantén la estructura de navegación** igual en todas las páginas para consistencia
- ⚠️ **Los CSS importan otros CSS** (ej: `loneliness.css` importa `depression.css`)
- ⚠️ **Todas las rutas de CSS/JS** están actualizadas según la ubicación del archivo
- ⚠️ **Los módulos usan rutas relativas** (`../`) para acceder a archivos del directorio padre

---

## 🔄 Equivalencia con el Archivo Original

El archivo original `inicio.html` estaba dividido en:

| Sección Original | Nuevo Archivo |
|------------------|---------------|
| Hero + Cards | `index.html` |
| Motivational | `index.html` |
| Sobre Nosotros | `sobre-nosotros.html` |
| Ayuda Emocional | `ayuda-emocional.html` |
| Test Emocional | `test-emocional.html` |
| Contacto | `contacto.html` |
| Depresión (módulo) | `modulos/depression.html` |
| Soledad (módulo) | `modulos/loneliness.html` |
| Apoyo (módulo) | `modulos/support.html` |
| Chat IA | `modulos/chat-ia.html` |

---

**¡Tu sitio está completamente modular y listo para mantener!** ✨
